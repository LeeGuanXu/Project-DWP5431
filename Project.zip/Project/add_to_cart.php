<?php
// Include configuration file
require_once 'config.php';

// Initialize response array
$response = [
    'success' => false,
    'message' => 'Failed to add item to cart'
];

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get item details from POST data
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name = isset($_POST['name']) ? sanitize_input($_POST['name']) : '';
    $price = isset($_POST['price']) ? floatval($_POST['price']) : 0;
    $image = isset($_POST['image']) ? sanitize_input($_POST['image']) : '';
    $category = isset($_POST['category']) ? sanitize_input($_POST['category']) : '';
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    
    // Validate data
    if ($id > 0 && !empty($name) && $price > 0) {
        // Initialize cart if it doesn't exist
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        
        // Check if item already exists in cart
        $item_exists = false;
        foreach ($_SESSION['cart'] as $key => $item) {
            if ($item['id'] == $id) {
                // Update quantity
                $_SESSION['cart'][$key]['quantity'] += $quantity;
                $item_exists = true;
                break;
            }
        }
        
        // Add new item to cart if it doesn't exist
        if (!$item_exists) {
            $_SESSION['cart'][] = [
                'id' => $id,
                'name' => $name,
                'price' => $price,
                'image' => $image,
                'category' => $category,
                'quantity' => $quantity
            ];
        }
        
        // Update response
        $response['success'] = true;
        $response['message'] = "$name added to cart";
        $response['cart_count'] = count($_SESSION['cart']);
    }
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
