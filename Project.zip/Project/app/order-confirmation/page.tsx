"use client"

import Link from "next/link"
import { CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function OrderConfirmationPage() {
  // Generate a random order ID
  const orderId = Math.floor(100000 + Math.random() * 900000)

  return (
    <div className="container mx-auto px-4 py-16 max-w-3xl">
      <div className="bg-white rounded-lg shadow-md p-8 text-center">
        <div className="flex justify-center mb-6">
          <CheckCircle size={80} className="text-green-500" />
        </div>

        <h1 className="text-3xl font-bold text-green-600 mb-4">Order Confirmed!</h1>
        <p className="text-lg text-gray-700 mb-2">Your order has been placed successfully.</p>
        <p className="text-gray-600 mb-8">Thank you for your purchase!</p>

        <div className="bg-gray-50 rounded-lg p-4 mb-8 inline-block">
          <p className="text-gray-700">
            Order ID: <span className="font-bold">#{orderId}</span>
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left mb-8">
          <div>
            <h3 className="text-xl font-semibold text-orange-500 mb-4">Order Details</h3>
            <div className="bg-orange-50 p-4 rounded-md mb-4">
              <p className="mb-2">
                <span className="font-medium">Order Status:</span> Processing
              </p>
              <p className="mb-2">
                <span className="font-medium">Payment Method:</span> Cash on Delivery
              </p>
              <p className="mb-2">
                <span className="font-medium">Delivery Time:</span> As Soon As Possible
              </p>
              <p>
                <span className="font-medium">Order Date:</span> {new Date().toLocaleString()}
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold text-orange-500 mb-4">Delivery Information</h3>
            <div className="bg-orange-50 p-4 rounded-md">
              <p className="mb-4">Your order will be delivered to your specified address within 15-30 minutes.</p>
              <p className="mb-2">
                <span className="font-medium">Tracking:</span> You will receive SMS updates about your order status.
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/">
            <Button className="bg-orange-500 hover:bg-orange-600">Continue Shopping</Button>
          </Link>
          <Link href="/menu">
            <Button variant="outline" className="border-orange-500 text-orange-500 hover:bg-orange-50">
              Browse Menu
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
