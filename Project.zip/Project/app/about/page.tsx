import Image from "next/image"

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md p-8">
        <h1 className="text-3xl font-bold text-orange-500 mb-8 text-center">About Us</h1>

        <div className="mb-10">
          <div className="relative w-full h-64 md:h-80 rounded-lg overflow-hidden mb-6">
            <Image
              src="/placeholder.svg?height=400&width=1200"
              alt="MMU Food Ordering Team"
              fill
              className="object-cover"
            />
          </div>

          <p className="text-gray-700 mb-4">
            Welcome to the MMU Food Ordering System, a project developed by students from Multimedia University Melaka.
            Our mission is to provide a convenient and efficient way for students and staff to order food from various
            cafeterias and food outlets around the campus.
          </p>

          <p className="text-gray-700 mb-4">
            This project was initiated in 2025 as part of our final year project, with the goal of improving the food
            ordering experience on campus. We understand the challenges of long queues and limited lunch breaks, which
            is why we created this platform to save time and enhance convenience.
          </p>

          <p className="text-gray-700">
            Our system connects students with all food vendors on campus, offering a wide variety of cuisines to satisfy
            every taste preference. From local Malaysian favorites to international dishes, we've got you covered!
          </p>
        </div>

        <h2 className="text-2xl font-semibold text-orange-500 mb-6">Our Team</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {[
            { name: "Ali bin Ahmad", role: "Frontend Developer", image: "/placeholder.svg?height=150&width=150" },
            { name: "Siti Aminah", role: "UI/UX Designer", image: "/placeholder.svg?height=150&width=150" },
            { name: "Raj Kumar", role: "Backend Developer", image: "/placeholder.svg?height=150&width=150" },
            { name: "Mei Ling", role: "Project Manager", image: "/placeholder.svg?height=150&width=150" },
          ].map((member, index) => (
            <div key={index} className="text-center">
              <div className="relative mx-auto w-32 h-32 rounded-full overflow-hidden mb-4 border-4 border-orange-100">
                <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
              </div>
              <h3 className="font-semibold text-lg">{member.name}</h3>
              <p className="text-orange-500 text-sm">{member.role}</p>
              <div className="flex justify-center mt-3 space-x-2">
                <a
                  href="#"
                  className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-white transition-colors"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-linkedin"
                  >
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                    <rect width="4" height="12" x="2" y="9" />
                    <circle cx="4" cy="4" r="2" />
                  </svg>
                </a>
                <a
                  href="#"
                  className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-white transition-colors"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-github"
                  >
                    <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4" />
                    <path d="M9 18c-4.51 2-5-2-7-2" />
                  </svg>
                </a>
                <a
                  href="#"
                  className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-white transition-colors"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="16"
                    height="16"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-twitter"
                  >
                    <path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z" />
                  </svg>
                </a>
              </div>
            </div>
          ))}
        </div>

        <h2 className="text-2xl font-semibold text-orange-500 mb-4">Our Vision</h2>
        <p className="text-gray-700 mb-6">
          We envision a campus where students can enjoy quality meals without the hassle of long queues or rushing
          between classes. Our goal is to continuously improve the food ordering experience at MMU Melaka and
          potentially expand to other campuses in the future.
        </p>

        <div className="bg-orange-50 p-6 rounded-lg border border-orange-100">
          <h3 className="text-xl font-semibold text-orange-800 mb-3">Our Mission</h3>
          <ul className="list-disc pl-5 space-y-2 text-gray-700">
            <li>Provide a seamless food ordering experience for MMU students and staff</li>
            <li>Support local food vendors on campus by increasing their visibility and sales</li>
            <li>Reduce waiting times and improve efficiency in campus dining</li>
            <li>Offer exclusive deals and promotions for the MMU community</li>
            <li>Continuously improve our platform based on user feedback</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
