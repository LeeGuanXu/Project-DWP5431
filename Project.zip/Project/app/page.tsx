import Link from "next/link"
import { FoodCard } from "@/components/food-card"
import { HeroSlider } from "@/components/hero-slider"
import { FeatureCard } from "@/components/feature-card"

// Sample food data
const featuredItems = [
  {
    id: "nasi-lemak",
    name: "Nasi Lemak",
    price: 6.0,
    description: "Rice cooked in coconut milk, served with sambal, egg, and peanuts. A Malaysian favorite!",
    image: "/images/nasi-lemak.jpg",
    category: "Malaysian",
    rating: 4.8,
    reviews: 124,
  },
  {
    id: "mee-goreng",
    name: "Mee Goreng",
    price: 5.5,
    description: "Fried noodles with vegetables, egg, and choice of meat or seafood. Spicy and flavorful!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Malaysian",
    rating: 4.6,
    reviews: 98,
  },
  {
    id: "chicken-rice",
    name: "Chicken Rice",
    price: 6.5,
    description: "Fragrant rice served with steamed or roasted chicken and chili sauce. Simple yet delicious!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Chinese",
    rating: 4.7,
    reviews: 112,
  },
]

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <HeroSlider />

      <section className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-10 m-6">
        <h2 className="text-2xl font-bold text-orange-500 mb-8 text-center relative pb-4 after:content-[''] after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-20 after:h-1 after:bg-orange-500 after:rounded">
          Featured Menu
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredItems.map((item) => (
            <FoodCard key={item.id} item={item} />
          ))}
        </div>

        <div className="text-center mt-8">
          <Link
            href="/menu"
            className="bg-orange-500 hover:bg-orange-600 text-white font-semibold py-3 px-6 rounded-md transition-colors shadow-md hover:shadow-lg inline-flex items-center"
          >
            View Full Menu
          </Link>
        </div>
      </section>

      <section className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-10 m-6">
        <h2 className="text-2xl font-bold text-orange-500 mb-8 text-center relative pb-4 after:content-[''] after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-20 after:h-1 after:bg-orange-500 after:rounded">
          Why Choose Us?
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <FeatureCard
            icon="truck"
            title="Fast Delivery"
            description="Get your food delivered within 30 minutes around MMU campus."
          />
          <FeatureCard
            icon="utensils"
            title="Quality Food"
            description="We use only the freshest ingredients for all our dishes."
          />
          <FeatureCard
            icon="tag"
            title="Student Discounts"
            description="Special prices and deals exclusively for MMU students."
          />
          <FeatureCard
            icon="headset"
            title="24/7 Support"
            description="Our customer service team is always ready to help you."
          />
        </div>
      </section>
    </main>
  )
}
