"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { useCart } from "@/hooks/use-cart"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/hooks/use-toast"

export default function CheckoutPage() {
  const router = useRouter()
  const { items, clearCart } = useCart()

  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    deliveryAddress: "",
    deliveryTime: "asap",
    paymentMethod: "cash",
    specialInstructions: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const subtotal = items.reduce((total, item) => total + item.price * item.quantity, 0)
  const deliveryFee = 2.0
  const taxRate = 0.06
  const tax = subtotal * taxRate
  const total = subtotal + deliveryFee + tax

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!formData.fullName || !formData.phone || !formData.deliveryAddress) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    // Process order (in a real app, this would send data to a server)
    toast({
      title: "Order Placed!",
      description: "Your order has been placed successfully.",
    })

    // Clear cart and redirect to confirmation
    clearCart()
    router.push("/order-confirmation")
  }

  if (items.length === 0) {
    router.push("/menu")
    return null
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-orange-500 mb-8">Checkout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-orange-800 mb-6">Delivery Information</h2>

            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="space-y-2">
                  <Label htmlFor="fullName">Full Name</Label>
                  <Input
                    id="fullName"
                    name="fullName"
                    placeholder="Your full name"
                    value={formData.fullName}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    name="phone"
                    placeholder="Your phone number"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2 mb-6">
                <Label htmlFor="deliveryAddress">Delivery Address</Label>
                <Textarea
                  id="deliveryAddress"
                  name="deliveryAddress"
                  placeholder="Room/Block/Building"
                  value={formData.deliveryAddress}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div className="space-y-2">
                  <Label htmlFor="deliveryTime">Delivery Time</Label>
                  <Select
                    value={formData.deliveryTime}
                    onValueChange={(value) => handleSelectChange("deliveryTime", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select delivery time" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="asap">As Soon As Possible</SelectItem>
                      <SelectItem value="lunch">Lunch (12:00 PM - 2:00 PM)</SelectItem>
                      <SelectItem value="dinner">Dinner (6:00 PM - 8:00 PM)</SelectItem>
                      <SelectItem value="custom">Schedule for Later</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="paymentMethod">Payment Method</Label>
                  <Select
                    value={formData.paymentMethod}
                    onValueChange={(value) => handleSelectChange("paymentMethod", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash on Delivery</SelectItem>
                      <SelectItem value="online">Online Banking</SelectItem>
                      <SelectItem value="ewallet">E-Wallet (Touch n Go, Boost)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2 mb-6">
                <Label htmlFor="specialInstructions">Special Instructions (Optional)</Label>
                <Textarea
                  id="specialInstructions"
                  name="specialInstructions"
                  placeholder="Any special instructions for your order..."
                  value={formData.specialInstructions}
                  onChange={handleChange}
                />
              </div>

              <Button type="submit" className="w-full md:w-auto bg-orange-500 hover:bg-orange-600">
                Place Order
              </Button>
            </form>
          </div>
        </div>

        <div>
          <div className="bg-orange-50 rounded-lg p-6 border border-orange-100">
            <h3 className="text-xl font-semibold text-orange-800 pb-4 mb-4 border-b border-orange-200">
              Order Summary
            </h3>

            <div className="space-y-4 mb-6">
              {items.map((item) => (
                <div key={item.id} className="flex items-center gap-3 pb-3 border-b border-orange-100">
                  <div className="relative h-14 w-14 rounded overflow-hidden flex-shrink-0">
                    <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                  </div>
                  <div className="flex-grow">
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-gray-600">
                      {item.quantity} x RM{item.price.toFixed(2)}
                    </p>
                  </div>
                  <p className="font-medium">RM{(item.price * item.quantity).toFixed(2)}</p>
                </div>
              ))}
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>RM{subtotal.toFixed(2)}</span>
              </div>

              <div className="flex justify-between">
                <span>Delivery Fee:</span>
                <span>RM{deliveryFee.toFixed(2)}</span>
              </div>

              <div className="flex justify-between">
                <span>Tax (6%):</span>
                <span>RM{tax.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t border-orange-200 text-xl font-bold text-orange-800">
              <span>Total:</span>
              <span>RM{total.toFixed(2)}</span>
            </div>

            <div className="mt-6 p-4 bg-orange-100 rounded-md text-sm">
              <p className="font-medium text-orange-800 mb-1">Delivery Information</p>
              <p className="text-orange-700">
                Delivery within MMU campus usually takes 15-30 minutes during regular hours.
              </p>
            </div>
          </div>

          <div className="mt-4 text-center">
            <Link href="/cart" className="text-orange-500 hover:underline inline-flex items-center gap-1">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="lucide lucide-arrow-left"
              >
                <path d="m12 19-7-7 7-7" />
                <path d="M19 12H5" />
              </svg>
              Back to Cart
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
