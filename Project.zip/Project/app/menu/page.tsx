"use client"

import { useState } from "react"
import { FoodCard } from "@/components/food-card"

// Sample food data
const foodItems = [
  {
    id: "nasi-lemak",
    name: "Nasi Lemak",
    price: 6.0,
    description: "Rice cooked in coconut milk, served with sambal, egg, and peanuts. A Malaysian favorite!",
    image: "/images/nasi-lemak.jpg",
    category: "Malaysian",
    rating: 4.8,
    reviews: 124,
  },
  {
    id: "mee-goreng",
    name: "Mee Goreng",
    price: 5.5,
    description: "Fried noodles with vegetables, egg, and choice of meat or seafood. Spicy and flavorful!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Malaysian",
    rating: 4.6,
    reviews: 98,
  },
  {
    id: "chicken-rice",
    name: "Chicken Rice",
    price: 6.5,
    description: "Fragrant rice served with steamed or roasted chicken and chili sauce. Simple yet delicious!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Chinese",
    rating: 4.7,
    reviews: 112,
  },
  {
    id: "char-kuey-teow",
    name: "Char Kuey Teow",
    price: 6.0,
    description: "Stir-fried flat rice noodles with prawns, bean sprouts, eggs, and chives. A hawker favorite!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Chinese",
    rating: 4.5,
    reviews: 87,
  },
  {
    id: "tom-yam-soup",
    name: "Tom Yam Soup",
    price: 7.0,
    description: "Hot and sour Thai soup with lemongrass, lime leaves, and seafood. Perfect for rainy days!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Thai",
    rating: 4.9,
    reviews: 76,
  },
  {
    id: "burger-ayam",
    name: "Burger Ayam",
    price: 5.0,
    description: "Chicken burger with lettuce, tomato, and special sauce. A quick meal for busy students!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Western",
    rating: 4.3,
    reviews: 65,
  },
  {
    id: "teh-tarik",
    name: "Teh Tarik",
    price: 2.0,
    description: "Pulled milk tea, a popular Malaysian drink. The perfect companion to any meal!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Drinks",
    rating: 4.7,
    reviews: 143,
  },
  {
    id: "ice-milo",
    name: "Ice Milo",
    price: 2.5,
    description: "Cold chocolate malt drink, popular among students. Refreshing and energizing!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Drinks",
    rating: 4.6,
    reviews: 118,
  },
  {
    id: "roti-canai",
    name: "Roti Canai",
    price: 1.5,
    description: "Flatbread served with curry or dhal. A Malaysian breakfast staple!",
    image: "/placeholder.svg?height=200&width=300",
    category: "Malaysian",
    rating: 4.8,
    reviews: 156,
  },
]

const categories = ["All", "Malaysian", "Chinese", "Thai", "Western", "Drinks"]

export default function MenuPage() {
  const [activeCategory, setActiveCategory] = useState("All")

  const filteredItems =
    activeCategory === "All" ? foodItems : foodItems.filter((item) => item.category === activeCategory)

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-orange-500 mb-8 text-center">Our Menu</h1>

      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
              activeCategory === category
                ? "bg-orange-500 text-white"
                : "bg-white text-orange-500 border border-orange-500 hover:bg-orange-50"
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredItems.map((item) => (
          <FoodCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  )
}
