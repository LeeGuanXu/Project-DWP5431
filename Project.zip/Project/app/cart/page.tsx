"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useCart } from "@/hooks/use-cart"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Trash2, ShoppingBag } from "lucide-react"

export default function CartPage() {
  const { items, updateQuantity, removeItem, clearCart } = useCart()
  const [promoCode, setPromoCode] = useState("")
  const [discount, setDiscount] = useState(0)
  const [specialInstructions, setSpecialInstructions] = useState("")

  const subtotal = items.reduce((total, item) => total + item.price * item.quantity, 0)
  const deliveryFee = 2.0
  const taxRate = 0.06
  const tax = subtotal * taxRate
  const total = subtotal + deliveryFee + tax - discount

  const applyPromoCode = () => {
    const validPromos = {
      STUDENT10: 10,
      WELCOME15: 15,
      MMUFOOD20: 20,
    }

    if (promoCode.toUpperCase() in validPromos) {
      const discountPercent = validPromos[promoCode.toUpperCase() as keyof typeof validPromos]
      const discountAmount = subtotal * (discountPercent / 100)
      setDiscount(discountAmount)
      alert(`Promo code applied! You get ${discountPercent}% off your order.`)
    } else {
      alert("Invalid promo code")
      setDiscount(0)
    }
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto">
          <div className="mb-6 flex justify-center">
            <ShoppingBag size={80} className="text-orange-500" />
          </div>
          <h1 className="text-2xl font-bold mb-4">Your cart is empty</h1>
          <p className="text-gray-600 mb-8">Looks like you haven't added any items to your cart yet.</p>
          <Link href="/menu">
            <Button className="bg-orange-500 hover:bg-orange-600">Browse Menu</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-orange-500 mb-8">Your Cart</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead>Price</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Subtotal</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="relative h-16 w-16 rounded overflow-hidden">
                          <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                        </div>
                        <div>
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-gray-500">{item.category}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>RM{item.price.toFixed(2)}</TableCell>
                    <TableCell>
                      <select
                        value={item.quantity}
                        onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value))}
                        className="w-16 p-2 border rounded"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                          <option key={num} value={num}>
                            {num}
                          </option>
                        ))}
                      </select>
                    </TableCell>
                    <TableCell className="font-medium">RM{(item.price * item.quantity).toFixed(2)}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeItem(item.id)}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 size={18} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-medium mb-3">Special Instructions</h3>
              <Textarea
                placeholder="Add any special instructions for your order..."
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                className="h-32"
              />
            </div>

            <div>
              <h3 className="text-lg font-medium mb-3">Promo Code</h3>
              <div className="flex gap-2">
                <Input
                  placeholder="Enter promo code"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                />
                <Button onClick={applyPromoCode} variant="outline" className="whitespace-nowrap">
                  Apply
                </Button>
              </div>
              <div className="mt-2 text-sm text-gray-500">Try: STUDENT10, WELCOME15, MMUFOOD20</div>
            </div>
          </div>
        </div>

        <div>
          <div className="bg-orange-50 rounded-lg p-6 border border-orange-100">
            <h3 className="text-xl font-semibold text-orange-800 pb-4 mb-4 border-b border-orange-200">
              Order Summary
            </h3>

            <div className="space-y-3 mb-4">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>RM{subtotal.toFixed(2)}</span>
              </div>

              {discount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount:</span>
                  <span>-RM{discount.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Delivery Fee:</span>
                <span>RM{deliveryFee.toFixed(2)}</span>
              </div>

              <div className="flex justify-between">
                <span>Tax (6%):</span>
                <span>RM{tax.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex justify-between pt-4 border-t border-orange-200 text-xl font-bold text-orange-800">
              <span>Total:</span>
              <span>RM{total.toFixed(2)}</span>
            </div>

            <Link href="/checkout">
              <Button className="w-full mt-6 bg-orange-500 hover:bg-orange-600">Proceed to Checkout</Button>
            </Link>

            <div className="mt-6 p-4 bg-orange-100 rounded-md text-sm">
              <p className="font-medium text-orange-800 mb-1">Delivery Information</p>
              <p className="text-orange-700">
                Delivery within MMU campus usually takes 15-30 minutes during regular hours.
              </p>
            </div>
          </div>

          <div className="mt-4 flex justify-center">
            <Image
              src="/student-discount.png"
              alt="Student Discount"
              width={300}
              height={150}
              className="rounded-md shadow-sm"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
