"use client"
import Image from "next/image"
import Link from "next/link"
import { Star, ShoppingCart, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/hooks/use-cart"
import { toast } from "@/hooks/use-toast"

interface FoodItem {
  id: string
  name: string
  price: number
  description: string
  image: string
  category: string
  rating: number
  reviews: number
}

interface FoodCardProps {
  item: FoodItem
}

export function FoodCard({ item }: FoodCardProps) {
  const { addItem } = useCart()

  // Generate star rating
  const fullStars = Math.floor(item.rating)
  const hasHalfStar = item.rating % 1 >= 0.5
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0)

  const handleAddToCart = () => {
    addItem({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image,
      category: item.category,
      quantity: 1,
    })

    toast({
      title: "Added to cart",
      description: `${item.name} has been added to your cart.`,
    })
  }

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative h-48 overflow-hidden">
        <Image
          src={item.image || "/placeholder.svg"}
          alt={item.name}
          fill
          className="object-cover transition-transform hover:scale-105"
        />
        <span className="absolute top-3 left-3 bg-white/90 text-orange-500 text-xs font-medium px-2 py-1 rounded-full">
          {item.category}
        </span>
      </div>

      <div className="p-5">
        <h3 className="font-semibold text-lg mb-1 text-gray-800">{item.name}</h3>
        <p className="text-orange-500 font-bold mb-2">RM{item.price.toFixed(2)}</p>

        <p className="text-gray-600 text-sm mb-3 line-clamp-2">{item.description}</p>

        <div className="flex items-center mb-4">
          <div className="flex text-yellow-400 mr-1">
            {[...Array(fullStars)].map((_, i) => (
              <Star key={`full-${i}`} size={16} fill="currentColor" />
            ))}
            {hasHalfStar && (
              <span className="relative">
                <Star size={16} className="text-gray-300" fill="currentColor" />
                <Star size={16} fill="currentColor" className="absolute top-0 left-0 w-1/2 overflow-hidden" />
              </span>
            )}
            {[...Array(emptyStars)].map((_, i) => (
              <Star key={`empty-${i}`} size={16} className="text-gray-300" fill="currentColor" />
            ))}
          </div>
          <span className="text-xs text-gray-500">
            ({item.rating}) • {item.reviews} reviews
          </span>
        </div>

        <div className="flex justify-between items-center">
          <Link
            href={`/menu/${item.id}`}
            className="text-orange-500 hover:text-orange-600 text-sm font-medium flex items-center gap-1"
          >
            View Details <ArrowRight size={14} />
          </Link>

          <Button size="sm" onClick={handleAddToCart} className="bg-orange-500 hover:bg-orange-600">
            <ShoppingCart size={14} className="mr-1" /> Add
          </Button>
        </div>
      </div>
    </div>
  )
}
