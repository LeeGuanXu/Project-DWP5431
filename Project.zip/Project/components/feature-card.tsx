import type { LucideIcon } from "lucide-react"
import { Truck, Utensils, Tag, Headset, Clock, CreditCard, ThumbsUp, Shield } from "lucide-react"

interface FeatureCardProps {
  icon: string
  title: string
  description: string
}

export function FeatureCard({ icon, title, description }: FeatureCardProps) {
  const getIcon = (): LucideIcon => {
    switch (icon) {
      case "truck":
        return Truck
      case "utensils":
        return Utensils
      case "tag":
        return Tag
      case "headset":
        return Headset
      case "clock":
        return Clock
      case "credit-card":
        return CreditCard
      case "thumbs-up":
        return ThumbsUp
      case "shield":
        return Shield
      default:
        return Utensils
    }
  }

  const Icon = getIcon()

  return (
    <div className="bg-white rounded-lg p-6 text-center border border-gray-100 hover:border-orange-100 transition-colors hover:shadow-md">
      <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-orange-100 flex items-center justify-center text-orange-500">
        <Icon size={28} />
      </div>
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  )
}
