import Link from "next/link"
import Image from "next/image"
import { Facebook, Twitter, Instagram, Linkedin, MapPin, Phone, Mail } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-gray-50 border-t border-gray-200 pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="relative w-10 h-10 overflow-hidden">
                <Image src="/food-order-logo.png" alt="MMU Food Ordering" fill className="object-contain" />
              </div>
              <h2 className="font-bold text-xl text-orange-500">MMU Food Ordering</h2>
            </div>
            <p className="text-gray-600 text-sm mb-6">
              Order delicious meals online from MMU Melaka campus – fast, simple, and convenient. We connect students
              with all food vendors on campus.
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-white transition-colors"
              >
                <Facebook size={16} />
              </a>
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-white transition-colors"
              >
                <Twitter size={16} />
              </a>
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-white transition-colors"
              >
                <Instagram size={16} />
              </a>
              <a
                href="#"
                className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center text-orange-500 hover:bg-orange-500 hover:text-white transition-colors"
              >
                <Linkedin size={16} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4 relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-orange-500">
              Quick Links
            </h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/"
                  className="text-gray-600 hover:text-orange-500 transition-colors flex items-center gap-1 text-sm"
                >
                  <span className="text-orange-500">›</span> Home
                </Link>
              </li>
              <li>
                <Link
                  href="/menu"
                  className="text-gray-600 hover:text-orange-500 transition-colors flex items-center gap-1 text-sm"
                >
                  <span className="text-orange-500">›</span> Menu
                </Link>
              </li>
              <li>
                <Link
                  href="/about"
                  className="text-gray-600 hover:text-orange-500 transition-colors flex items-center gap-1 text-sm"
                >
                  <span className="text-orange-500">›</span> About Us
                </Link>
              </li>
              <li>
                <Link
                  href="/contact"
                  className="text-gray-600 hover:text-orange-500 transition-colors flex items-center gap-1 text-sm"
                >
                  <span className="text-orange-500">›</span> Contact
                </Link>
              </li>
              <li>
                <Link
                  href="/login"
                  className="text-gray-600 hover:text-orange-500 transition-colors flex items-center gap-1 text-sm"
                >
                  <span className="text-orange-500">›</span> Login
                </Link>
              </li>
              <li>
                <Link
                  href="/register"
                  className="text-gray-600 hover:text-orange-500 transition-colors flex items-center gap-1 text-sm"
                >
                  <span className="text-orange-500">›</span> Register
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4 relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-orange-500">
              Contact Us
            </h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin size={18} className="text-orange-500 flex-shrink-0 mt-0.5" />
                <span className="text-gray-600 text-sm">
                  Jalan Ayer Keroh Lama, 75450 Bukit Beruang, Melaka, Malaysia
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Phone size={18} className="text-orange-500 flex-shrink-0" />
                <span className="text-gray-600 text-sm">+606-252 3997</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail size={18} className="text-orange-500 flex-shrink-0" />
                <span className="text-gray-600 text-sm">info@mmu.edu.my</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg mb-4 relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-0.5 after:bg-orange-500">
              Newsletter
            </h3>
            <p className="text-gray-600 text-sm mb-4">
              Subscribe to our newsletter to get updates on our latest offers!
            </p>
            <div className="flex gap-2">
              <Input type="email" placeholder="Your email address" className="h-10" />
              <Button size="icon" className="h-10 w-10 bg-orange-500 hover:bg-orange-600">
                <Mail size={16} />
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 pt-6 text-center">
          <p className="text-gray-600 text-sm">
            &copy; {currentYear} MMU Food Ordering System | Multimedia University Melaka. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}
