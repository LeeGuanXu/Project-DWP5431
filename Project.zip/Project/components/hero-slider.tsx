"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

const slides = [
  {
    title: "Delicious Food at Your Fingertips",
    description:
      "Order your favorite meals from MMU Cafeteria. Fast delivery, student-friendly prices, and delicious food!",
    image: "/placeholder.svg?height=400&width=500",
    buttonText: "Order Now",
    buttonLink: "/menu",
  },
  {
    title: "Special Student Discounts",
    description: "Exclusive deals for MMU students! Show your student ID and get 10% off on all orders.",
    image: "/student-discount.png",
    buttonText: "View Deals",
    buttonLink: "/menu",
  },
  {
    title: "New! Healthy Options",
    description: "Try our new range of healthy meals, perfect for a balanced diet during busy study days.",
    image: "/placeholder.svg?height=400&width=500",
    buttonText: "Explore Menu",
    buttonLink: "/menu",
  },
]

export function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0)

  // Auto-advance slides
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 6000)

    return () => clearInterval(interval)
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  const goToSlide = (index: number) => {
    setCurrentSlide(index)
  }

  return (
    <div className="relative overflow-hidden rounded-lg mx-6 mt-6 shadow-lg">
      <div className="relative h-[500px] bg-gradient-to-r from-orange-50 to-white">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 flex flex-col md:flex-row items-center transition-opacity duration-500 ${
              index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
            }`}
          >
            <div className="w-full md:w-1/2 p-8 md:p-16">
              <h2 className="text-3xl md:text-4xl font-bold text-orange-500 mb-4">{slide.title}</h2>
              <p className="text-gray-700 mb-6 max-w-md">{slide.description}</p>
              <Link href={slide.buttonLink}>
                <Button className="bg-orange-500 hover:bg-orange-600">{slide.buttonText}</Button>
              </Link>
            </div>
            <div className="w-full md:w-1/2 p-8 flex justify-center items-center">
              <div className="relative w-full max-w-md h-64 md:h-80">
                <Image src={slide.image || "/placeholder.svg"} alt={slide.title} fill className="object-contain" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/80 flex items-center justify-center text-orange-500 hover:bg-white hover:text-orange-600 transition-colors shadow-md"
      >
        <ChevronLeft size={24} />
      </button>

      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/80 flex items-center justify-center text-orange-500 hover:bg-white hover:text-orange-600 transition-colors shadow-md"
      >
        <ChevronRight size={24} />
      </button>

      {/* Indicators */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`w-3 h-3 rounded-full transition-colors ${
              index === currentSlide ? "bg-orange-500" : "bg-white/50 hover:bg-white"
            }`}
          />
        ))}
      </div>
    </div>
  )
}
