<?php
// Include configuration file
require_once 'config.php';

// Initialize response array
$response = [
    'success' => false,
    'message' => 'Invalid promo code'
];

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get promo code from POST data
    $promo_code = isset($_POST['promo_code']) ? sanitize_input($_POST['promo_code']) : '';
    
    // Valid promo codes and their discount percentages
    $valid_promos = [
        'STUDENT10' => 10,
        'WELCOME15' => 15,
        'MMUFOOD20' => 20
    ];
    
    // Check if promo code is valid
    if (!empty($promo_code) && array_key_exists(strtoupper($promo_code), $valid_promos)) {
        // Apply discount
        $_SESSION['promo_code'] = strtoupper($promo_code);
        $_SESSION['discount_percentage'] = $valid_promos[strtoupper($promo_code)];
        
        $response['success'] = true;
        $response['message'] = "Promo code applied! You get {$_SESSION['discount_percentage']}% off your order.";
        $response['discount_percentage'] = $_SESSION['discount_percentage'];
    }
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
