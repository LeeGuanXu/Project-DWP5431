<?php
// Include configuration file
require_once 'config.php';

// Initialize response array
$response = [
    'success' => false,
    'message' => 'Failed to update cart'
];

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get action and index from POST data
    $action = isset($_POST['action']) ? sanitize_input($_POST['action']) : '';
    $index = isset($_POST['index']) ? intval($_POST['index']) : -1;
    
    // Check if cart exists and index is valid
    if (isset($_SESSION['cart']) && $index >= 0 && $index < count($_SESSION['cart'])) {
        if ($action === 'update') {
            // Update quantity
            $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
            if ($quantity > 0 && $quantity <= 10) {
                $_SESSION['cart'][$index]['quantity'] = $quantity;
                $response['success'] = true;
                $response['message'] = 'Cart updated successfully';
            }
        } elseif ($action === 'remove') {
            // Remove item from cart
            array_splice($_SESSION['cart'], $index, 1);
            $response['success'] = true;
            $response['message'] = 'Item removed from cart';
        }
    }
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
