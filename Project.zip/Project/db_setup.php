<?php
// Include configuration file
require_once 'config.php';

// SQL to create users table
$sql_users = "CREATE TABLE IF NOT EXISTS users (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    student_id VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

// SQL to create food_categories table
$sql_categories = "CREATE TABLE IF NOT EXISTS food_categories (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// SQL to create food_items table
$sql_food_items = "CREATE TABLE IF NOT EXISTS food_items (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255),
    category_id INT(11) UNSIGNED,
    rating DECIMAL(3,1) DEFAULT 0,
    reviews INT(11) DEFAULT 0,
    is_featured TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES food_categories(id) ON DELETE SET NULL
)";

// SQL to create orders table
$sql_orders = "CREATE TABLE IF NOT EXISTS orders (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) UNSIGNED,
    total_amount DECIMAL(10,2) NOT NULL,
    delivery_fee DECIMAL(10,2) DEFAULT 0,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
    payment_method VARCHAR(50),
    delivery_address TEXT,
    delivery_time VARCHAR(50),
    special_instructions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
)";

// SQL to create order_items table
$sql_order_items = "CREATE TABLE IF NOT EXISTS order_items (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT(11) UNSIGNED NOT NULL,
    food_item_id INT(11) UNSIGNED NOT NULL,
    quantity INT(11) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (food_item_id) REFERENCES food_items(id) ON DELETE CASCADE
)";

// Execute the SQL statements
$conn->query($sql_users);
$conn->query($sql_categories);
$conn->query($sql_food_items);
$conn->query($sql_orders);
$conn->query($sql_order_items);

// Insert sample food categories
$categories = [
    ['Malaysian', 'Traditional Malaysian cuisine'],
    ['Chinese', 'Authentic Chinese dishes'],
    ['Thai', 'Spicy and flavorful Thai food'],
    ['Western', 'Western style meals and snacks'],
    ['Drinks', 'Refreshing beverages']
];

foreach ($categories as $category) {
    $stmt = $conn->prepare("INSERT IGNORE INTO food_categories (name, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $category[0], $category[1]);
    $stmt->execute();
    $stmt->close();
}

// Insert sample food items
$food_items = [
    ['Nasi Lemak', 'Rice cooked in coconut milk, served with sambal, egg, and peanuts. A Malaysian favorite!', 6.00, '/images/nasilemak.jpg', 1, 4.8, 124, 1],
    ['Mee Goreng', 'Fried noodles with vegetables, egg, and choice of meat or seafood. Spicy and flavorful!', 5.50, '/images/mee-goreng.jpg', 1, 4.6, 98, 1],
    ['Chicken Rice', 'Fragrant rice served with steamed or roasted chicken and chili sauce. Simple yet delicious!', 6.50, '/images/chicken-rice.jpg', 2, 4.7, 112, 1],
    ['Char Kuey Teow', 'Stir-fried flat rice noodles with prawns, bean sprouts, eggs, and chives. A hawker favorite!', 6.00, '/images/char-kuey-teow.jpg', 2, 4.5, 87, 0],
    ['Tom Yam Soup', 'Hot and sour Thai soup with lemongrass, lime leaves, and seafood. Perfect for rainy days!', 7.00, '/images/tom-yam.jpg', 3, 4.9, 76, 0],
    ['Burger Ayam', 'Chicken burger with lettuce, tomato, and special sauce. A quick meal for busy students!', 5.00, '/images/burger-ayam.jpg', 4, 4.3, 65, 0],
    ['Teh Tarik', 'Pulled milk tea, a popular Malaysian drink. The perfect companion to any meal!', 2.00, '/images/teh-tarik.jpg', 5, 4.7, 143, 0],
    ['Ice Milo', 'Cold chocolate malt drink, popular among students. Refreshing and energizing!', 2.50, '/images/ice-milo.jpg', 5, 4.6, 118, 0],
    ['Roti Canai', 'Flatbread served with curry or dhal. A Malaysian breakfast staple!', 1.50, '/images/roti-canai.jpg', 1, 4.8, 156, 0]
];

foreach ($food_items as $item) {
    $stmt = $conn->prepare("INSERT IGNORE INTO food_items (name, description, price, image, category_id, rating, reviews, is_featured) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsidii", $item[0], $item[1], $item[2], $item[3], $item[4], $item[5], $item[6], $item[7]);
    $stmt->execute();
    $stmt->close();
}

echo "Database setup completed successfully!";
$conn->close();
?>
