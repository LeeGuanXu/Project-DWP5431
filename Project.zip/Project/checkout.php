<?php
// Include configuration file
require_once 'config.php';

// Check if cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    redirect('cart.php', 'Your cart is empty. Please add items to your cart before checkout.', 'warning');
}

// Initialize variables
$cart_items = $_SESSION['cart'];
$subtotal = 0;
$delivery_fee = 2.00;
$tax_rate = 0.06; // 6% tax
$discount = 0;

// Calculate subtotal
foreach ($cart_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

// Apply discount if promo code is applied
if (isset($_SESSION['discount_percentage'])) {
    $discount = $subtotal * ($_SESSION['discount_percentage'] / 100);
    $subtotal -= $discount;
}

// Calculate tax and total
$tax = $subtotal * $tax_rate;
$total = $subtotal + $delivery_fee + $tax;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $full_name = sanitize_input($_POST['full_name']);
    $phone = sanitize_input($_POST['phone']);
    $delivery_address = sanitize_input($_POST['delivery_address']);
    $delivery_time = sanitize_input($_POST['delivery_time']);
    $payment_method = sanitize_input($_POST['payment_method']);
    $special_instructions = isset($_POST['special_instructions']) ? sanitize_input($_POST['special_instructions']) : '';
    
    // Validate form data
    if (empty($full_name) || empty($phone) || empty($delivery_address) || empty($delivery_time) || empty($payment_method)) {
        $error = 'Please fill in all required fields';
    } else {
        // Get user ID if logged in
        $user_id = is_logged_in() ? $_SESSION['user_id'] : null;
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Insert order into database
            $sql = "INSERT INTO orders (user_id, total_amount, delivery_fee, tax_amount, payment_method, delivery_address, delivery_time, special_instructions) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("idddssss", $user_id, $total, $delivery_fee, $tax, $payment_method, $delivery_address, $delivery_time, $special_instructions);
            $stmt->execute();
            
            // Get order ID
            $order_id = $conn->insert_id;
            
            // Insert order items
            $sql = "INSERT INTO order_items (order_id, food_item_id, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            
            foreach ($cart_items as $item) {
                $item_subtotal = $item['price'] * $item['quantity'];
                $stmt->bind_param("iiidd", $order_id, $item['id'], $item['quantity'], $item['price'], $item_subtotal);
                $stmt->execute();
            }
            
            // Commit transaction
            $conn->commit();
            
            // Clear cart and promo code
            unset($_SESSION['cart']);
            unset($_SESSION['promo_code']);
            unset($_SESSION['discount_percentage']);
            
            // Redirect to order confirmation page
            redirect('order-confirmation.php?order_id=' . $order_id, 'Your order has been placed successfully!', 'success');
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $error = 'An error occurred while processing your order. Please try again.';
        }
    }
}

// Include the HTML header
include 'header.php';
?>

<!-- Checkout Tab -->
<div id="checkout" class="tab-content active">
    <section class="content-section">
        <h2 class="section-title">Checkout</h2>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger mb-4">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div class="md:col-span-2">
                <h3 class="text-xl font-semibold text-primary mb-4">Delivery Information</h3>

                <form id="checkout-form" method="post" action="checkout.php">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="form-group">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="full_name" class="form-control" placeholder="Your full name" value="<?php echo is_logged_in() ? $_SESSION['user_name'] : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" name="phone" class="form-control" placeholder="Your phone number" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Delivery Address</label>
                        <textarea name="delivery_address" class="form-control" placeholder="Room/Block/Building" required rows="3"></textarea>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="form-group">
                            <label class="form-label">Delivery Time</label>
                            <select name="delivery_time" class="form-control" required>
                                <option value="asap">As Soon As Possible</option>
                                <option value="lunch">Lunch (12:00 PM - 2:00 PM)</option>
                                <option value="dinner">Dinner (6:00 PM - 8:00 PM)</option>
                                <option value="custom">Schedule for Later</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Payment Method</label>
                            <select name="payment_method" class="form-control" required>
                                <option value="cash">Cash on Delivery</option>
                                <option value="online">Online Banking</option>
                                <option value="ewallet">E-Wallet (Touch n Go, Boost)</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Special Instructions (Optional)</label>
                        <textarea name="special_instructions" class="form-control" placeholder="Any special instructions for your order..." rows="3"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg mt-4">Place Order</button>
                </form>
            </div>

            <div>
                <div class="cart-summary">
                    <h3 class="cart-summary-title">Order Summary</h3>

                    <div class="mb-4">
                        <?php foreach ($cart_items as $item): ?>
                            <div class="flex items-center gap-3 mb-3 pb-3 border-b">
                                <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" class="cart-item-img">
                                <div>
                                    <p class="font-medium"><?php echo $item['name']; ?></p>
                                    <p class="text-sm text-gray-600"><?php echo $item['quantity']; ?> x RM<?php echo number_format($item['price'], 2); ?></p>
                                </div>
                                <p class="ml-auto">RM<?php echo number_format($item['price'] * $item['quantity'], 2); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="cart-summary-row">
                        <span>Subtotal:</span>
                        <span>RM<?php echo number_format($subtotal, 2); ?></span>
                    </div>

                    <?php if (isset($_SESSION['discount_percentage'])): ?>
                    <div class="cart-summary-row">
                        <span>Discount (<?php echo $_SESSION['discount_percentage']; ?>%):</span>
                        <span>-RM<?php echo number_format($discount, 2); ?></span>
                    </div>
                    <?php endif; ?>

                    <div class="cart-summary-row">
                        <span>Delivery Fee:</span>
                        <span>RM<?php echo number_format($delivery_fee, 2); ?></span>
                    </div>
                    
                    <div class="cart-summary-row">
                        <span>Tax (6%):</span>
                        <span>RM<?php echo number_format($tax, 2); ?></span>
                    </div>

                    <div class="cart-summary-row total">
                        <span>Total:</span>
                        <span>RM<?php echo number_format($total, 2); ?></span>
                    </div>

                    <div class="mt-4 p-3 bg-primary-light rounded text-sm">
                        <p class="font-medium text-primary">Delivery Information</p>
                        <p class="mt-1">
                            Delivery within MMU campus usually takes 15-30 minutes during regular hours.
                        </p>
                    </div>
                </div>

                <div class="mt-4 text-center">
                    <a href="cart.php" class="text-primary hover:underline">
                        <i class="fas fa-arrow-left"></i> Back to Cart
                    </a>
                </div>
            </div>
        </div>
    </section>
</div>

<?php
// Include the HTML footer
include 'footer.php';
?>
