<?php

// Assume $food_items is an array of food items, each with 'image', 'name', and 'category' keys.
// Example:
// $food_items = [
//     ['image' => 'images/pizza.jpg', 'name' => 'Pizza', 'category' => 'Italian'],
//     ['image' => 'images/burger.jpg', 'name' => 'Burger', 'category' => 'American'],
//     ['image' => 'images/sushi.jpg', 'name' => 'Sushi', 'category' => 'Japanese'],
// ];

// Function to check if an image path exists (replace with your actual implementation)
function debug_image_path($image_path) {
    // In a real application, you would check if the file exists.
    // For this example, we'll just return true if the path is not empty.
    return !empty($image_path);
}

function get_image_path($image_path) {
    $image_exists = false;

    if (!empty($image_path)) {
        // Try different path variations
        $possible_paths = [
            $image_path,                    // Original path
            './' . $image_path,             // Relative with ./
            '../' . $image_path,            // Up one directory
            dirname(__FILE__) . '/' . $image_path, // Absolute server path
        ];

        foreach ($possible_paths as $path) {
            if (file_exists($path)) {
                $image_exists = true;
                $image_path = $path;
                break;
            }
        }
    }

    // Use the image if it exists, otherwise use placeholder
    return $image_exists ? $image_path : 'https://via.placeholder.com/300x200/ff6b35/ffffff?text=' . urlencode($item['name']);
}

?>

<div class="menu">
    <h2>Our Menu</h2>
    <div class="food-grid">
        <?php foreach ($food_items as $item): ?>
            <div class="food-card">
                <?php
                    // Debug image path
                    $image_path = !empty($item['image']) ? $item['image'] : '';
                    $image_exists = false;

                    if (!empty($image_path)) {
                        // Try different path variations
                        $possible_paths = [
                            $image_path,                    // Original path
                            './' . $image_path,             // Relative with ./
                            '../' . $image_path,            // Up one directory
                            dirname(__FILE__) . '/' . $image_path, // Absolute server path
                        ];

                        foreach ($possible_paths as $path) {
                            if (file_exists($path)) {
                                $image_exists = true;
                                $image_path = $path;
                                break;
                            }
                        }
                    }

                    // Use the image if it exists, otherwise use placeholder
                    $img_src = $image_exists ? $image_path : 'https://via.placeholder.com/300x200/ff6b35/ffffff?text=' . urlencode($item['name']);
                ?>
                <img src="<?php echo get_image_path($item['image']); ?>" alt="<?php echo $item['name']; ?>" class="food-card-img">
                <!-- Debug info (hidden in HTML comment):
                     Original path: <?php echo $item['image']; ?>
                     Image exists: <?php echo $image_exists ? 'Yes' : 'No'; ?>
                     Final path used: <?php echo $img_src; ?>
                -->
                <div class="food-category"><?php echo $item['category']; ?></div>
                <!-- Rest of your food card code -->
                <button class="btn btn-sm btn-primary add-to-cart" data-id="<?php echo $item['id']; ?>" data-name="<?php echo $item['name']; ?>" data-price="<?php echo $item['price']; ?>" data-image="<?php echo get_image_path($item['image']); ?>" data-category="<?php echo $item['category_name']; ?>">
                    <i class="fas fa-cart-plus"></i> Add
                </button>
            </div>
        <?php endforeach; ?>
    </div>
</div>
