// Food data
const foodItems = [
  {
    id: "nasilemak",
    name: "Nasi Lemak",
    price: 6.0,
    description: "Rice cooked in coconut milk, served with sambal, egg, and peanuts. A Malaysian favorite!",
    image: "nasilemak.jpg",
    category: "Malaysian",
    rating: 4.8,
    reviews: 124
  },
  {
    id: "mee-goreng",
    name: "Mee Goreng",
    price: 5.5,
    description: "Fried noodles with vegetables, egg, and choice of meat or seafood. Spicy and flavorful!",
    image: "https://via.placeholder.com/300x200/ff9f1c/ffffff?text=Mee+Goreng",
    category: "Malaysian",
    rating: 4.6,
    reviews: 98
  },
  {
    id: "chicken-rice",
    name: "Chicken Rice",
    price: 6.5,
    description: "Fragrant rice served with steamed or roasted chicken and chili sauce. Simple yet delicious!",
    image: "https://via.placeholder.com/300x200/2ec4b6/ffffff?text=Chicken+Rice",
    category: "Chinese",
    rating: 4.7,
    reviews: 112
  },
  {
    id: "char-kuey-teow",
    name: "Char Kuey Teow",
    price: 6.0,
    description: "Stir-fried flat rice noodles with prawns, bean sprouts, eggs, and chives. A hawker favorite!",
    image: "https://via.placeholder.com/300x200/ff6b35/ffffff?text=Char+Kuey+Teow",
    category: "Chinese",
    rating: 4.5,
    reviews: 87
  },
  {
    id: "tom-yam-soup",
    name: "Tom Yam Soup",
    price: 7.0,
    description: "Hot and sour Thai soup with lemongrass, lime leaves, and seafood. Perfect for rainy days!",
    image: "https://via.placeholder.com/300x200/ff9f1c/ffffff?text=Tom+Yam",
    category: "Thai",
    rating: 4.9,
    reviews: 76
  },
  {
    id: "burger-ayam",
    name: "Burger Ayam",
    price: 5.0,
    description: "Chicken burger with lettuce, tomato, and special sauce. A quick meal for busy students!",
    image: "https://via.placeholder.com/300x200/2ec4b6/ffffff?text=Burger+Ayam",
    category: "Western",
    rating: 4.3,
    reviews: 65
  },
  {
    id: "teh-tarik",
    name: "Teh Tarik",
    price: 2.0,
    description: "Pulled milk tea, a popular Malaysian drink. The perfect companion to any meal!",
    image: "https://via.placeholder.com/300x200/ff6b35/ffffff?text=Teh+Tarik",
    category: "Drinks",
    rating: 4.7,
    reviews: 143
  },
  {
    id: "ice-milo",
    name: "Ice Milo",
    price: 2.5,
    description: "Cold chocolate malt drink, popular among students. Refreshing and energizing!",
    image: "https://via.placeholder.com/300x200/ff9f1c/ffffff?text=Ice+Milo",
    category: "Drinks",
    rating: 4.6,
    reviews: 118
  },
  {
    id: "roti-canai",
    name: "Roti Canai",
    price: 1.5,
    description: "Flatbread served with curry or dhal. A Malaysian breakfast staple!",
    image: "https://via.placeholder.com/300x200/2ec4b6/ffffff?text=Roti+Canai",
    category: "Malaysian",
    rating: 4.8,
    reviews: 156
  }
];

// DOM Elements
const header = document.getElementById('header');
const mobileMenuBtn = document.getElementById('mobile-menu-btn');
const navLinks = document.getElementById('nav-links');
const tabLinks = document.querySelectorAll('.tab-link');
const categoryBtns = document.querySelectorAll('.category-btn');
const foodDetailTabBtns = document.querySelectorAll('.food-detail-tab-btn');
const addToCartDetailBtn = document.getElementById('add-to-cart-detail');
const cartQuantitySelects = document.querySelectorAll('.cart-quantity');
const cartRemoveBtns = document.querySelectorAll('.cart-remove-btn');
const checkoutForm = document.getElementById('checkout-form');
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const contactForm = document.getElementById('contact-form');

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  // Populate featured menu
  populateFeaturedMenu();
  
  // Populate full menu
  populateMenu('All');
  
  // Initialize hero slider
  showSlide(currentSlide);
  setInterval(nextSlide, 6000);
  
  // Initialize cart
  updateCartTotals();
  
  // Scroll event for header
  window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
  
  // Mobile menu toggle
  mobileMenuBtn.addEventListener('click', function() {
    navLinks.classList.toggle('active');
    this.innerHTML = navLinks.classList.contains('active') 
      ? '<i class="fas fa-times"></i>' 
      : '<i class="fas fa-bars"></i>';
  });
  
  // Tab navigation
  tabLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const tabId = this.getAttribute('data-tab');
      openTab(tabId);
      
      // Handle food detail view
      if (tabId === 'food-detail') {
        const foodId = this.getAttribute('data-food');
        if (foodId) {
          showFoodDetail(foodId);
        }
      }
      
      // Update URL hash
      window.location.hash = tabId;
      
      // Close mobile menu if open
      if (navLinks.classList.contains('active')) {
        navLinks.classList.remove('active');
        mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
      }
      
      // Update active nav link
      tabLinks.forEach(link => {
        link.classList.remove('active');
      });
      document.querySelectorAll(`.tab-link[data-tab="${tabId}"]`).forEach(link => {
        link.classList.add('active');
      });
      
      // Scroll to top
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  });
  
  // Check URL hash on page load
  const hash = window.location.hash.substring(1);
  if (hash) {
    openTab(hash);
    // Update active nav link
    tabLinks.forEach(link => {
      link.classList.remove('active');
    });
    document.querySelectorAll(`.tab-link[data-tab="${hash}"]`).forEach(link => {
      link.classList.add('active');
    });
  }
  
  // Category buttons
  categoryBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const category = this.getAttribute('data-category');
      
      // Update active button
      categoryBtns.forEach(b => {
        b.classList.remove('btn-primary');
        b.classList.add('btn-outline');
      });
      this.classList.remove('btn-outline');
      this.classList.add('btn-primary');
      
      populateMenu(category);
    });
  });
  
  // Food detail tab buttons
  foodDetailTabBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const tabId = this.getAttribute('data-tab');
      
      // Update active button
      foodDetailTabBtns.forEach(b => {
        b.classList.remove('active');
      });
      this.classList.add('active');
      
      // Show tab content
      document.querySelectorAll('.food-detail-tab-content').forEach(content => {
        content.classList.remove('active');
      });
      document.getElementById(tabId).classList.add('active');
    });
  });
  
  // Add to cart from detail page
  addToCartDetailBtn.addEventListener('click', function() {
    const foodId = this.getAttribute('data-food');
    const quantity = parseInt(document.getElementById('quantity').value);
    addToCart(foodId, quantity);
  });
  
  // Cart quantity selects
  cartQuantitySelects.forEach(select => {
    select.addEventListener('change', function() {
      updateCartTotals();
    });
  });
  
  // Cart remove buttons
  cartRemoveBtns.forEach(btn => {
    btn.addEventListener('click', function() {
      const itemId = this.getAttribute('data-id');
      removeFromCart(itemId);
    });
  });
  
  // Form submissions
  if (checkoutForm) {
    checkoutForm.addEventListener('submit', function(e) {
      e.preventDefault();
      alert('Your order has been placed successfully!');
      openTab('home');
    });
  }
  
  if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
      e.preventDefault();
      alert('Login successful!');
      openTab('home');
    });
  }
  
  if (registerForm) {
    registerForm.addEventListener('submit', function(e) {
      e.preventDefault();
      const password = this.querySelector('input[type="password"]').value;
      const confirmPassword = this.querySelectorAll('input[type="password"]')[1].value;
      
      if (password !== confirmPassword) {
        const errorDiv = document.getElementById('register-error');
        errorDiv.textContent = "Passwords do not match";
        errorDiv.classList.remove('hidden');
        return;
      }
      
      alert('Registration successful! Please login.');
      openTab('login');
    });
  }
  
  if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
      e.preventDefault();
      alert('Message sent! We\'ll get back to you soon.');
      this.reset();
    });
  }
});

// Tab functionality
function openTab(tabId) {
  // Hide all tabs
  const tabContents = document.querySelectorAll('.tab-content');
  tabContents.forEach(tab => {
    tab.classList.remove('active');
  });
  
  // Show selected tab
  const selectedTab = document.getElementById(tabId);
  if (selectedTab) {
    selectedTab.classList.add('active');
  }
}

// Populate featured menu
function populateFeaturedMenu() {
  const featuredMenu = document.getElementById('featured-menu');
  if (!featuredMenu) return;
  
  featuredMenu.innerHTML = '';
  
  // Get first 3 items
  const featuredItems = foodItems.slice(0, 3);
  
  featuredItems.forEach(item => {
    featuredMenu.appendChild(createFoodCard(item));
  });
}

// Populate menu
function populateMenu(category) {
  const menuGrid = document.getElementById('menu-grid');
  if (!menuGrid) return;
  
  menuGrid.innerHTML = '';
  
  const filteredItems = category === 'All' 
    ? foodItems 
    : foodItems.filter(item => item.category === category);
  
  filteredItems.forEach(item => {
    menuGrid.appendChild(createFoodCard(item));
  });
}

// Create food card
function createFoodCard(item) {
  const foodCard = document.createElement('div');
  foodCard.className = 'food-card';
  
  // Generate star rating HTML
  const fullStars = Math.floor(item.rating);
  const hasHalfStar = item.rating % 1 >= 0.5;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
  
  let starsHtml = '';
  for (let i = 0; i < fullStars; i++) {
    starsHtml += '<i class="fas fa-star"></i>';
  }
  if (hasHalfStar) {
    starsHtml += '<i class="fas fa-star-half-alt"></i>';
  }
  for (let i = 0; i < emptyStars; i++) {
    starsHtml += '<i class="far fa-star"></i>';
  }
  
  foodCard.innerHTML = `
    <div class="food-card-img-container">
      <img src="${item.image}" alt="${item.name}" class="food-card-img">
      <span class="food-card-category">${item.category}</span>
    </div>
    <div class="food-card-content">
      <h3 class="food-card-title">${item.name}</h3>
      <p class="food-card-price">RM${item.price.toFixed(2)}</p>
      <p class="food-card-desc">${item.description}</p>
      <div class="food-card-rating">
        ${starsHtml}
        <span>(${item.rating}) • ${item.reviews} reviews</span>
      </div>
      <div class="food-card-actions">
        <a href="#food-detail" class="tab-link" data-tab="food-detail" data-food="${item.id}">
          View Details <i class="fas fa-arrow-right"></i>
        </a>
        <button class="btn btn-sm btn-primary add-to-cart" data-id="${item.id}">
          <i class="fas fa-cart-plus"></i> Add
        </button>
      </div>
    </div>
  `;
  
  // Add event listeners
  const viewDetailsLink = foodCard.querySelector('.tab-link');
  viewDetailsLink.addEventListener('click', function(e) {
    e.preventDefault();
    const tabId = this.getAttribute('data-tab');
    const foodId = this.getAttribute('data-food');
    
    openTab(tabId);
    showFoodDetail(foodId);
    
    window.location.hash = tabId;
    
    // Scroll to top
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
  
  const addToCartBtn = foodCard.querySelector('.add-to-cart');
  addToCartBtn.addEventListener('click', function() {
    const foodId = this.getAttribute('data-id');
    addToCart(foodId);
  });
  
  return foodCard;
}

// Food detail functionality
function showFoodDetail(foodId) {
  const food = foodItems.find(item => item.id === foodId);
  if (!food) return;
  
  document.getElementById('food-detail-title').textContent = food.name;
  document.getElementById('food-detail-img').src = food.image;
  document.getElementById('food-detail-img').alt = food.name;
  document.getElementById('food-detail-category').textContent = food.category;
  document.getElementById('food-detail-desc').textContent = food.description;
  document.getElementById('food-detail-price').textContent = `RM${food.price.toFixed(2)}`;
  
  // Set food ID for add to cart button
  document.getElementById('add-to-cart-detail').setAttribute('data-food', food.id);
  
  // Reset quantity
  document.getElementById('quantity').value = "1";
}

// Hero slider functionality
let currentSlide = 0;
const slides = document.querySelectorAll('.hero-slide');
const indicators = document.querySelectorAll('.hero-indicator');

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.remove('active');
  });
  indicators.forEach((indicator, i) => {
    indicator.classList.remove('active');
  });
  
  slides[index].classList.add('active');
  indicators[index].classList.add('active');
}

function nextSlide() {
  currentSlide = (currentSlide + 1) % slides.length;
  showSlide(currentSlide);
}

function prevSlide() {
  currentSlide = (currentSlide - 1 + slides.length) % slides.length;
  showSlide(currentSlide);
}

function goToSlide(index) {
  currentSlide = index;
  showSlide(currentSlide);
}

// Cart functionality
function addToCart(foodId, quantity = 1) {
  const food = foodItems.find(item => item.id === foodId);
  if (!food) return;
  
  // Check if item already in cart
  const existingItem = document.querySelector(`.cart-quantity[data-id="${foodId}"]`);
  
  if (existingItem) {
    // Increment quantity
    const currentQty = parseInt(existingItem.value);
    existingItem.value = Math.min(currentQty + quantity, 10);
  } else {
    // Add new item to cart
    const cartItems = document.getElementById('cart-items');
    const newRow = document.createElement('tr');
    newRow.innerHTML = `
      <td>
        <div class="cart-item-info">
          <img src="${food.image}" alt="${food.name}" class="cart-item-img">
          <div>
            <p class="cart-item-name">${food.name}</p>
            <small>${food.category}</small>
          </div>
        </div>
      </td>
      <td>RM${food.price.toFixed(2)}</td>
      <td>
        <select class="form-control cart-quantity" data-id="${food.id}" data-price="${food.price.toFixed(2)}">
          ${Array.from({length: 10}, (_, i) => `<option value="${i+1}" ${i+1 === quantity ? 'selected' : ''}>${i+1}</option>`).join('')}
        </select>
      </td>
      <td>RM${(food.price * quantity).toFixed(2)}</td>
      <td>
        <button class="cart-remove-btn" data-id="${food.id}">
          <i class="fas fa-trash-alt"></i> Remove
        </button>
      </td>
    `;
    cartItems.appendChild(newRow);
    
    // Add event listeners to new elements
    const newQuantitySelect = newRow.querySelector('.cart-quantity');
    newQuantitySelect.addEventListener('change', function() {
      updateCartTotals();
    });
    
    const newRemoveBtn = newRow.querySelector('.cart-remove-btn');
    newRemoveBtn.addEventListener('click', function() {
      removeFromCart(food.id);
    });
  }
  
  // Update cart totals
  updateCartTotals();
  
  // Show success message with animation
  const notification = document.createElement('div');
  notification.className = 'notification';
  notification.innerHTML = `
    <div class="notification-content">
      <i class="fas fa-check-circle"></i>
      <span>${food.name} added to cart!</span>
    </div>
  `;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: var(--primary);
    color: white;
    padding: 1rem;
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-md);
    z-index: 1000;
    animation: slideIn 0.3s ease forwards, fadeOut 0.3s ease 2.7s forwards;
  `;
  
  document.body.appendChild(notification);
  
  // Add animation styles
  const style = document.createElement('style');
  style.innerHTML = `
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    @keyframes fadeOut {
      from { opacity: 1; }
      to { opacity: 0; }
    }
    .notification-content {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
  `;
  document.head.appendChild(style);
  
  // Remove notification after 3 seconds
  setTimeout(() => {
    notification.remove();
  }, 3000);
}

function removeFromCart(itemId) {
  const cartItem = document.querySelector(`.cart-quantity[data-id="${itemId}"]`).closest('tr');
  
  // Add animation
  cartItem.style.animation = 'fadeOut 0.3s ease forwards';
  
  // Remove after animation
  setTimeout(() => {
    cartItem.remove();
    updateCartTotals();
  }, 300);
}

function updateCartTotals() {
  let subtotal = 0;
  const deliveryFee = 2.00;
  const taxRate = 0.06; // 6% tax
  
  //Calculate subtotal
  document.querySelectorAll('.cart-quantity').forEach(select => {
    const price = parseFloat(select.getAttribute('data-price'));
    const quantity = parseInt(select.value);
    const itemTotal = price * quantity;
    
    //更新item subtotal
    const subtotalCell = select.closest('tr').querySelector('td:nth-child(4)');
    subtotalCell.textContent = `RM${itemTotal.toFixed(2)}`;
    
    subtotal += itemTotal;
  });
  
  const tax = subtotal * taxRate;
  const total = subtotal + deliveryFee + tax;
  
  //更新cart summary
  const subtotalElem = document.getElementById('cart-subtotal');
  const totalElem = document.getElementById('cart-total');
  
  if (subtotalElem) subtotalElem.textContent = `RM${subtotal.toFixed(2)}`;
  if (totalElem) totalElem.textContent = `RM${total.toFixed(2)}`;
  
  // Show和hide的empty cart message
  const cartItems = document.querySelectorAll('.cart-quantity');
  const emptyCart = document.getElementById('empty-cart');
  const cartContent = document.getElementById('cart-content');
  
  if (cartItems.length === 0) {
    if (emptyCart) emptyCart.classList.remove('hidden');
    if (cartContent) cartContent.classList.add('hidden');
  } else {
    if (emptyCart) emptyCart.classList.add('hidden');
    if (cartContent) cartContent.classList.remove('hidden');
  }
}
