<?php
// Include configuration file
require_once 'config.php';

// Initialize variables
$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$subtotal = 0;
$delivery_fee = 2.00;
$tax_rate = 0.06; // 6% tax

// Calculate subtotal
foreach ($cart_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

// Calculate tax and total
$tax = $subtotal * $tax_rate;
$total = $subtotal + $delivery_fee + $tax;

// Include the HTML header
include 'header.php';
?>

<!-- Cart Tab -->
<div id="cart" class="tab-content active">
    <section class="content-section">
        <h2 class="section-title">Your Cart</h2>

        <?php if (empty($cart_items)): ?>
            <div id="empty-cart" class="text-center py-8">
                <img src="https://via.placeholder.com/150/ff6b35/ffffff?text=Empty+Cart" alt="Empty Cart" width="150" height="150" class="mx-auto mb-4">
                <p class="text-lg mb-6">Your cart is empty</p>
                <a href="menu.php" class="btn btn-primary">Browse Menu</a>
            </div>
        <?php else: ?>
            <div id="cart-content">
                <div class="overflow-x-auto">
                    <table class="cart-table">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="cart-items">
                            <?php foreach ($cart_items as $index => $item): ?>
                                <tr>
                                    <td>
                                        <div class="cart-item-info">
                                            <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" class="cart-item-img">
                                            <div>
                                                <p class="cart-item-name"><?php echo $item['name']; ?></p>
                                                <small><?php echo $item['category']; ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>RM<?php echo number_format($item['price'], 2); ?></td>
                                    <td>
                                        <select class="form-control cart-quantity" data-index="<?php echo $index; ?>" data-price="<?php echo $item['price']; ?>">
                                            <?php for ($i = 1; $i <= 10; $i++): ?>
                                                <option value="<?php echo $i; ?>" <?php echo $i == $item['quantity'] ? 'selected' : ''; ?>><?php echo $i; ?></option>
                                            <?php endfor; ?>
                                        </select>
                                    </td>
                                    <td>RM<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                    <td>
                                        <button class="cart-remove-btn" data-index="<?php echo $index; ?>">
                                            <i class="fas fa-trash-alt"></i> Remove
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5">
                    <div>
                        <div class="form-group">
                            <label class="form-label">Special Instructions</label>
                            <textarea class="form-control" id="special-instructions" placeholder="Add any special instructions for your order..." rows="3"></textarea>
                        </div>
                        
                        <div class="cart-promo">
                            <label class="form-label">Promo Code</label>
                            <div class="cart-promo-input">
                                <input type="text" class="form-control" id="promo-code" placeholder="Enter promo code">
                                <button class="btn btn-outline" id="apply-promo">Apply</button>
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="cart-summary">
                            <h3 class="cart-summary-title">Order Summary</h3>

                            <div class="cart-summary-row">
                                <span>Subtotal:</span>
                                <span id="cart-subtotal">RM<?php echo number_format($subtotal, 2); ?></span>
                            </div>

                            <div class="cart-summary-row">
                                <span>Delivery Fee:</span>
                                <span>RM<?php echo number_format($delivery_fee, 2); ?></span>
                            </div>
                            
                            <div class="cart-summary-row">
                                <span>Tax (6%):</span>
                                <span>RM<?php echo number_format($tax, 2); ?></span>
                            </div>

                            <div class="cart-summary-row total">
                                <span>Total:</span>
                                <span id="cart-total">RM<?php echo number_format($total, 2); ?></span>
                            </div>

                            <a href="checkout.php" class="btn btn-primary btn-block mt-4">
                                Proceed to Checkout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </section>
</div>

<script>
    // Update cart quantity
    document.querySelectorAll('.cart-quantity').forEach(select => {
        select.addEventListener('change', function() {
            const index = this.getAttribute('data-index');
            const quantity = parseInt(this.value);
            
            // Send AJAX request to update cart
            fetch('update_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=update&index=${index}&quantity=${quantity}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Reload the page to show updated cart
                    window.location.reload();
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    });
    
    // Remove item from cart
    document.querySelectorAll('.cart-remove-btn').forEach(button => {
        button.addEventListener('click', function() {
            const index = this.getAttribute('data-index');
            
            // Send AJAX request to remove item from cart
            fetch('update_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=remove&index=${index}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Reload the page to show updated cart
                    window.location.reload();
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    });
    
    // Apply promo code
    document.getElementById('apply-promo').addEventListener('click', function() {
        const promoCode = document.getElementById('promo-code').value.trim();
        
        if (promoCode) {
            // Send AJAX request to apply promo code
            fetch('apply_promo.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `promo_code=${encodeURIComponent(promoCode)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message and reload page
                    alert(data.message);
                    window.location.reload();
                } else {
                    // Show error message
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        } else {
            alert('Please enter a promo code');
        }
    });
</script>

<?php
// Include the HTML footer
include 'footer.php';
?>
