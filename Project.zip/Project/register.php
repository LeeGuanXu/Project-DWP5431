<?php
// Include configuration file
require_once 'config.php';

// Check if user is already logged in
if (is_logged_in()) {
    redirect('index.php');
}

// Initialize variables
$full_name = '';
$email = '';
$phone = '';
$student_id = '';
$error = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $full_name = sanitize_input($_POST['full_name']);
    $email = sanitize_input($_POST['email']);
    $phone = sanitize_input($_POST['phone']);
    $student_id = sanitize_input($_POST['student_id']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate form data
    if (empty($full_name) || empty($email) || empty($phone) || empty($password) || empty($confirm_password)) {
        $error = 'Please fill in all required fields';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long';
    } else {
        // Check if email already exists
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $error = 'Email already exists. Please use a different email or login.';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user into database
            $sql = "INSERT INTO users (full_name, email, phone, student_id, password) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssss", $full_name, $email, $phone, $student_id, $hashed_password);
            
            if ($stmt->execute()) {
                // Redirect to login page
                redirect('login.php', 'Registration successful! Please login.', 'success');
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}

// Include the HTML header
include 'header.php';
?>

<!-- Register Tab -->
<div id="register" class="tab-content active">
    <section class="content-section max-w-md mx-auto">
        <h2 class="section-title">Create an Account</h2>

        <div class="text-center mb-6">
            <img src="https://via.placeholder.com/100/ff6b35/ffffff?text=Register" alt="Register" width="100" height="100" class="mx-auto">
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger mb-4">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form id="register-form" method="post" action="register.php">
            <div class="form-group">
                <label class="form-label">Full Name</label>
                <input type="text" name="full_name" class="form-control" placeholder="Your full name" value="<?php echo $full_name; ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="Your email" value="<?php echo $email; ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Phone Number</label>
                <input type="tel" name="phone" class="form-control" placeholder="Your phone number" value="<?php echo $phone; ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Student ID (Optional)</label>
                <input type="text" name="student_id" class="form-control" placeholder="Your student ID" value="<?php echo $student_id; ?>">
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Create a password" required>
                <small class="text-muted">Password must be at least 6 characters long</small>
            </div>

            <div class="form-group">
                <label class="form-label">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Confirm your password" required>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Register</button>
        </form>

        <div class="text-center mt-4">
            <p>Already have an account?</p>
            <a href="login.php" class="btn btn-outline mt-2">Login</a>
        </div>
    </section>
</div>

<?php
// Include the HTML footer
include 'footer.php';
?>
