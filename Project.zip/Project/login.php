<?php
// Include configuration file
require_once 'config.php';

// Check if user is already logged in
if (is_logged_in()) {
    redirect('index.php');
}

// Initialize variables
$email = '';
$password = '';
$error = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    
    // Validate form data
    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        // Check if user exists
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Verify password
            if (password_verify($password, $user['password'])) {
                // Set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['user_email'] = $user['email'];
                
                // Redirect to home page
                redirect('index.php', 'Login successful! Welcome back, ' . $user['full_name'], 'success');
            } else {
                $error = 'Invalid email or password';
            }
        } else {
            $error = 'Invalid email or password';
        }
    }
}

// Include the HTML header
include 'header.php';
?>

<!-- Login Tab -->
<div id="login" class="tab-content active">
    <section class="content-section max-w-md mx-auto">
        <h2 class="section-title">Login to Your Account</h2>

        <div class="text-center mb-6">
            <img src="https://via.placeholder.com/100/ff6b35/ffffff?text=Login" alt="Login" width="100" height="100" class="mx-auto">
        </div>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger mb-4">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form id="login-form" method="post" action="login.php">
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="Your email" value="<?php echo $email; ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Your password" required>
            </div>

            <div class="form-check mb-4">
                <input type="checkbox" id="rememberMe" name="rememberMe" class="form-check-input">
                <label for="rememberMe">Remember me</label>
            </div>

            <button type="submit" class="btn btn-primary btn-block">Login</button>
        </form>

        <div class="text-center mt-4">
            <a href="forgot-password.php" class="text-primary hover:underline">Forgot Password?</a>
        </div>

        <div class="text-center mt-4">
            <p>Don't have an account?</p>
            <a href="register.php" class="btn btn-outline mt-2">Create Account</a>
        </div>
    </section>
</div>

<?php
// Include the HTML footer
include 'footer.php';
?>
