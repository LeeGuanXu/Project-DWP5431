<?php
// Debug image paths
function debug_image_path($path) {
    $full_path = __DIR__ . '/' . $path;
    if (file_exists($full_path)) {
        return true;
    } else {
        error_log("Image not found: " . $full_path);
        return false;
    }
}
?>
