<?php
// Include configuration file
require_once 'config.php';

// Check if order ID is provided
if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    redirect('index.php');
}

// Get order ID
$order_id = intval($_GET['order_id']);

// Get order details
$order = null;
$order_items = [];

$sql = "SELECT * FROM orders WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $order = $result->fetch_assoc();
    
    // Get order items
    $sql = "SELECT oi.*, f.name, f.image FROM order_items oi 
            JOIN food_items f ON oi.food_item_id = f.id 
            WHERE oi.order_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $order_items[] = $row;
    }
} else {
    redirect('index.php', 'Order not found', 'error');
}

// Include the HTML header
include 'header.php';
?>

<!-- Order Confirmation Tab -->
<div id="order-confirmation" class="tab-content active">
    <section class="content-section">
        <div class="text-center mb-6">
            <i class="fas fa-check-circle text-success" style="font-size: 4rem; color: #28a745;"></i>
            <h2 class="section-title">Order Confirmed!</h2>
            <p class="mb-4">Your order has been placed successfully. Thank you for your purchase!</p>
            <p class="mb-4">Order ID: <strong>#<?php echo $order_id; ?></strong></p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
                <h3 class="text-xl font-semibold text-primary mb-4">Order Details</h3>
                
                <div class="bg-primary-light p-4 rounded-md mb-4">
                    <p><strong>Order Status:</strong> <?php echo ucfirst($order['status']); ?></p>
                    <p><strong>Payment Method:</strong> <?php echo ucfirst($order['payment_method']); ?></p>
                    <p><strong>Delivery Time:</strong> <?php echo ucfirst($order['delivery_time']); ?></p>
                    <p><strong>Order Date:</strong> <?php echo date('F j, Y, g:i a', strtotime($order['created_at'])); ?></p>
                </div>
                
                <h4 class="text-lg font-semibold mb-2">Delivery Address</h4>
                <p class="mb-4"><?php echo nl2br($order['delivery_address']); ?></p>
                
                <?php if (!empty($order['special_instructions'])): ?>
                    <h4 class="text-lg font-semibold mb-2">Special Instructions</h4>
                    <p class="mb-4"><?php echo nl2br($order['special_instructions']); ?></p>
                <?php endif; ?>
            </div>
            
            <div>
                <h3 class="text-xl font-semibold text-primary mb-4">Order Summary</h3>
                
                <div class="cart-summary">
                    <div class="mb-4">
                        <?php foreach ($order_items as $item): ?>
                            <div class="flex items-center gap-3 mb-3 pb-3 border-b">
                                <img src="<?php echo !empty($item['image']) ? $item['image'] : 'https://via.placeholder.com/60/ff6b35/ffffff?text=' . substr($item['name'], 0, 2); ?>" alt="<?php echo $item['name']; ?>" class="cart-item-img">
                                <div>
                                    <p class="font-medium"><?php echo $item['name']; ?></p>
                                    <p class="text-sm text-gray-600"><?php echo $item['quantity']; ?> x RM<?php echo number_format($item['price'], 2); ?></p>
                                </div>
                                <p class="ml-auto">RM<?php echo number_format($item['subtotal'], 2); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="cart-summary-row">
                        <span>Subtotal:</span>
                        <span>RM<?php echo number_format($order['total_amount'] - $order['delivery_fee'] - $order['tax_amount'], 2); ?></span>
                    </div>

                    <div class="cart-summary-row">
                        <span>Delivery Fee:</span>
                        <span>RM<?php echo number_format($order['delivery_fee'], 2); ?></span>
                    </div>
                    
                    <div class="cart-summary-row">
                        <span>Tax (6%):</span>
                        <span>RM<?php echo number_format($order['tax_amount'], 2); ?></span>
                    </div>

                    <div class="cart-summary-row total">
                        <span>Total:</span>
                        <span>RM<?php echo number_format($order['total_amount'], 2); ?></span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="text-center mt-6">
            <a href="index.php" class="btn btn-primary">Continue Shopping</a>
            <?php if (is_logged_in()): ?>
                <a href="account.php" class="btn btn-outline ml-2">View My Orders</a>
            <?php endif; ?>
        </div>
    </section>
</div>

<?php
// Include the HTML footer
include 'footer.php';
?>
